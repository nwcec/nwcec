<?php
//api url filter
if(strpos($_SERVER['REQUEST_URI'],"DB.php")){
    require_once 'Utils.php';
    PlainDie();
}

$conn = new mysqli("localhost", "id18371735_nwcecmods","$6m]@vPTc?DNDwZv","id18371735_nwcec");
if($conn->connect_error != null){
    die($conn->connect_error);
}